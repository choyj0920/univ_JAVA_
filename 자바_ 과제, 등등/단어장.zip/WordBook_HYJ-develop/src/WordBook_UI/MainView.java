package WordBook_UI;

import java.awt.Container;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import WordBook_DATA.UserDatabase;
import WordBook_DATA.Word;
import WordBook_DATA.Worddata;

public class MainView {
	
	public static void main(String[] args) throws IOException {
		
		Worddata.set_wordbook();
		UserDatabase.loadUserdb();
		//word.findWord();
		FrameManager fm=new FrameManager();
	}


	
}
