package WordBook_UI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import WordBook_DATA.User;
import WordBook_DATA.UserDatabase;
import WordBook_DATA.Worddata;

public class LoginPanel extends JPanel {

	UserDatabase users=new UserDatabase();
	public JButton login;
	public JButton back;
	private JTextField id;
	private JPasswordField password;
	private FrameManager manager;
	JOptionPane jOption=new JOptionPane();
	
	LoginPanel(FrameManager Fm) {
		setLayout(null);
		manager = Fm;

		JLabel idLabel = new JLabel("���̵�");
		idLabel.setBounds(31, 40, 67, 15);
		add(idLabel);
		id = new JTextField(20);
		id.setBounds(100, 40, 80, 20);
		add(id);
		id.setColumns(10);

		JLabel pwLabel = new JLabel("��й�ȣ");
		pwLabel.setBounds(31, 90, 90, 15);
		add(pwLabel);
		password = new JPasswordField(20);
		password.setBounds(100, 90, 80, 20);
		password.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					isSuccessLogin();
				}
			}
		});
		add(password);
		password.setColumns(10);
		
		back=new JButton("�ڷ� ����");
		back.setBounds(410,20,120,70);
		add(back);
		back.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				manager.changeFrame("����â");				
			}
		});
		login = new JButton("�α���");
		login.setBounds(410, 90, 120, 70);
		add(login);
		login.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				isSuccessLogin();
			}
		});
	}

	public void isSuccessLogin() {
		String checkId=id.getText();
		String checkPw=password.getText();
		manager.nowUser=UserDatabase.loaduserfile(checkId, checkPw);
		if(manager.nowUser !=null) {
			manager.changeFrame("�ܾ���View");
		}else {
			jOption.showMessageDialog(null,"���̵� �Ǵ� ��й�ȣ�� ���� �ʽ��ϴ�.");
		}
	
	}

}
