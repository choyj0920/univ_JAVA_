package WordBook_UI;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;

import WordBook_DATA.Word;
import WordBook_DATA.Worddata;

public class TotalWordBook extends JPanel {

	private FrameManager manager;
	Word words = new Word();
	JPanel wordlistpanel=new JPanel();
	JPanel controllpanel=new JPanel();
	JList<String>list;
	JButton btn=new JButton("�� �ܾ� �� �ܾ��忡 �߰�");

	public TotalWordBook(FrameManager Fm) {
		manager = Fm;
		
		btn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String[] ss=list.getSelectedValue().split(":");
				String worde=ss[1].split(",")[0].trim();
				String[] means=ss[2].trim().split("/");
				for(int i=0;i<means.length;i++) {
					means[i].trim();
				}
				if(manager.nowUser.putword(worde, means)) {
					JOptionPane.showMessageDialog(null,"���������� �߰��Ǿ����ϴ�~");
				}
				else {
					JOptionPane.showMessageDialog(null,"�̹� �����ϴ� �ܾ��Դϴ�.");
					
				}
				
			}
		});
		controllpanel.add(btn);
		setLayout(new BorderLayout());
		wordlistpanel.setLayout(new BorderLayout());
		
		
		String[] ss= new String[Worddata.wordbook.size()];
		for(int i=0; i<Worddata.wordbook.size();i++) {
			ss[i]=Worddata.wordbook.get(i).toString();
		}
		list=new JList(ss);
		if(manager.nowUser!=null)
			add(controllpanel,BorderLayout.EAST);
			
		wordlistpanel.add(new JScrollPane(list));
		add(wordlistpanel);
		
	}
}
