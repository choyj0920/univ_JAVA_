package WordBook_UI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import WordBook_DATA.UserDatabase;
import WordBook_DATA.Word;
import WordBook_DATA.Worddata;

public class myWordBook extends JPanel {

	private FrameManager manager;
	
	JPanel wordlistpanel;
	JPanel controllpanel;
	JList<String>list;
	JButton btn;

	public myWordBook(FrameManager Fm) {
		manager = Fm;
		
		init();
		
		
	}
	void init() {
		this.removeAll();
		
		btn=new JButton("�� �ܾ��忡�� ����");
		btn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					String[] ss=list.getSelectedValue().split(":");
					String worde=ss[1].split(",")[0].trim();
					manager.nowUser.userWordbook.remove(worde);
					JOptionPane.showMessageDialog(null,"���������� ���ŵǾ����ϴ�.");
					UserDatabase.saveuserdata();
					init();
					
				} catch (Exception e2) {
					// TODO: handle exception
					System.out.println(e.toString());
					JOptionPane.showMessageDialog(null,"���� �߻�..�ܾ ����� ���õ��� �ʾҽ��ϴ�.");
				}
				
				
			}
		});
		setLayout(new BorderLayout());
		controllpanel=new JPanel();
		controllpanel.add(btn);
		ArrayList<Word> arr=new ArrayList<Word>();
		arr.addAll(manager.nowUser.userWordbook.values());
		String[] ss= new String[arr.size()];
		for(int i=0; i<ss.length;i++) {
			ss[i]=arr.get(i).toString();
		}
		list=new JList(ss);
		if(manager.nowUser!=null)
			add(controllpanel,BorderLayout.EAST);
		wordlistpanel=new JPanel();
		wordlistpanel.setLayout(new BorderLayout());
		wordlistpanel.add(new JScrollPane(list));
		add(wordlistpanel);
		manager.getContentPane().validate();
	}
}
