package WordBook_DATA;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Word implements Comparable<Word> {

	File file = new File("words.txt");
	static Random rand = new Random();
	private String word_e;
	private String[] mean;
	
	String[] result;

	public Word(String worde,String[] mean) {
		this.word_e=worde;
		this.mean = mean;

	}

	public Word() {
		// TODO Auto-generated constructor stub
	}



	public String getWord_e() {
		return word_e;
	}

	public String[] getMean() {
		return mean;
	}

	public boolean correct(String dd) {
		for (int i = 0; i < mean.length; i++) {
			if (mean[i].equals(dd))
				return true;
		}
		return false;
	}

	public String checkMean(int i) {
		return mean[i];
	}

	public String randMean() {
		return mean[rand.nextInt(mean.length)];
	}

	@Override
	public String toString() {
		String ss="";
		for(int i=0; i<mean.length;i++) {
			ss+=mean[i]+"/";
		}
		return "���� : " + word_e + ", �� :" + ss;
	}
	public String toFile() {
		String ss="";
		for(int i=0; i<mean.length;i++) {
			ss+=mean[i]+"/";
		}
		ss+="\n";
		
		return word_e+"\n"+ss;
	}
	
	@Override
	public int hashCode() {// Set���� ���� ���- hashcode ����θ�
		// TODO Auto-generated method stub
		return word_e.hashCode();
	}

	@Override
	public boolean equals(Object obj) { // set���� ������� - Word.equals�� ��� ��
		// TODO Auto-generated method stub
		if (obj instanceof Word)
			return word_e.equals(((Word) obj).word_e);
		return false;
	}

	@Override
	public int compareTo(Word o) {
		// TODO Auto-generated method stub
		return word_e.compareTo(o.word_e);
	}

	

}