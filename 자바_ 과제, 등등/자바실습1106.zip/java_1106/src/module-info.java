module java_1106 {
}