package RacingCar;

import java.util.Random;

public class Car {     
	private final String name;     
	private int position = 0;     
	public Car(String name) {         
		this.name = name;     
		}    
	// �߰� ��� ���� 
	public void move(){
		if(isprocess())
			position++;
	}
	public String getName() {
		return name;
	}
	public int getPosition() {
		return position;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String str=this.name+" : ";
		for(int i=0;i<position;i++) {
			str += "-";
		}
		return str;
	}
	static boolean isprocess() {
		Random rand= new Random();
		int n=rand.nextInt(10);
		if(n<4)
			return false;
		return true;
	}
}