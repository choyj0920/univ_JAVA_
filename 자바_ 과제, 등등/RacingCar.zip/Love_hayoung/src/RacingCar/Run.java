package RacingCar;

import java.util.ArrayList;
import java.util.Random;

public class Run {
	
	Car[] cars;
	int Trycount;
	
	public boolean setCarsName(String n) {//names���� ���ڿ��� �޾� ������ 	
		String[] names = n.split(",");
		for(String str:names) {
			if(!checkStrLength5(str)) {
				return false;
			}
		}
		initCar(names);
		return true;
	}
	public void initCar(String[] names) {//Car�迭�� ����
		cars=new Car[names.length];
		for(int i=0 ; i<cars.length; i++) {
			cars[i]=new Car(names[i]);
		}
	}
	public void setTryCount(int n) {//�õ� Ƚ�� �����Լ�
		Trycount=n;
	}
	public void run_Race() { //�õ� Ƚ����ŭ �õ� �Լ�
		System.out.println("\n���� ���");
		for(int i=0;i<Trycount;i++) {
			try_race();
			printTryResult();
		}
	}
	public void try_race() {//�ѹ� �õ��� �Լ�
		for(Car c:cars) {
			c.move();
		}
	}
	public void printTryResult() {//���� ��� ����Լ�
		for(int i=0; i<cars.length;i++) {
			System.out.println(cars[i]);
		}
		System.out.println();
	}
	ArrayList<Integer> getMaxDistanceCarIndex(){
		ArrayList<Integer> maxDisCars=new ArrayList<>();
		int max=0;
		for(int i=0; i<cars.length;i++) {
			if(max < cars[i].getPosition()) {
				max=cars[i].getPosition();
				maxDisCars.clear();
				maxDisCars.add(i);
				continue;
			}
			if(max== cars[i].getPosition())
				maxDisCars.add(i);				
		}
		return maxDisCars;
	}
	public void print_result() {
		// TODO Auto-generated method stub
		ArrayList<Integer> maxDisCars=getMaxDistanceCarIndex();
		System.out.print(cars[maxDisCars.get(0)].getName());
		for(int i=1;i<maxDisCars.size();i++) {
			System.out.print(", "+cars[maxDisCars.get(i)].getName());
		}
		System.out.println("�� ���� ��� �߽��ϴ�");
		
	}
	static boolean	checkStrLength5(String str){
		if(str.length() <= 5)
			return true;
		return false;
	}
	
}
