package konkuk.yjcho;

public class Manager {
	private String Mname;
	static final int maxcount=10;
	private int count;
	private Item[] Ilist;
	private int total;
	public Manager(String mname) {
		super();
		total=0;
		Mname = mname;
		Ilist=new Item[maxcount];
		this.count=0;
	}
	
	public void register(Item item) {
		if(count>=maxcount) {
			System.out.println("�� �̻� ��� �Ҽ� ����..");
			return;
		}
		if(item instanceof Coffee) {
			for(int i=0;i<count;i++) {
				if(Ilist[i] instanceof Coffee) {
					if(Ilist[i].getIname().equals(item.getIname())) {
						System.out.println("���� �޴��� �ߺ� ��ϵ� �� ����");
						return;
					}
				}
			}
			Ilist[count++]=item;
			System.out.println(item.getIname()+" �޴���� �Ϸ�");
		}
		else if(item instanceof Beer) {
			for(int i=0;i<count;i++) {
				if(Ilist[i] instanceof Beer) {
					if(Ilist[i].getIname().equals(item.getIname())) {
						Beer b1 =(Beer)Ilist[i];
						Beer b2 =(Beer)item;
						if(b1.isFresh()==b2.isFresh()) {
							System.out.println("���� �޴��� ��ϵɼ� ����");
							return;
						}
					}
				}
			}
			Ilist[count++]=item;
			System.out.println(item.getIname()+" �޴���� �Ϸ�");
		}

	}
	public void order(Client c,Item[] item) {
		for(int i=0;i<item.length;i++) {
			if(item[i] instanceof Coffee) {
				for(int j=0;j<count;j++) {
					if(Ilist[j] instanceof Coffee) {
						if(item[i].getIname().equals(Ilist[j].getIname())) {
							Ilist[j].sellcountup();
							c.setTotal(c.getTotal()+Ilist[j].getPrice());
							total+=Ilist[j].getPrice();
							System.out.println(item[i].getIname()+ " ���ſϷ�");
							continue;
						}
					}
				}
				
				
			}
			else if(item[i] instanceof Beer) {
				if(c.getAge()<19) {
					System.out.println(item[i].getIname()+"��  19�� �̻� ������ �� ����");
					return;
				}
				for(int j=0;j<count;j++) {
					if(Ilist[j] instanceof Beer) {
						if(item[i].getIname().equals(Ilist[j].getIname())) {
							Beer b1=(Beer)item[i];
							Beer b2=(Beer)Ilist[j];
							if(b1.isFresh() != b2.isFresh())
								continue;
							
							Ilist[j].sellcountup();
							c.setTotal(c.getTotal()+Ilist[j].getPrice());
							total+=Ilist[j].getPrice();
							System.out.println(item[i].getIname()+ " ���ſϷ�");
							
						}
					}
				}
			
				
			}
		}
	}
	public void show() {
		System.out.println(Mname+"�� �Ǹ���Ȳ");
		System.out.println("ǰ��\t�ǸŰ���\t���ǸŰ���\t���Ǹűݾ�");
		for(int i=0;i<count;i++) {
			String ss="";
			
			ss += Ilist[i].getIname()+"\t"+Ilist[i].getPrice()+"\t"+Ilist[i].getSellcount()+"\t"+(Ilist[i].getSellcount()*Ilist[i].getPrice());
			System.out.println(ss);
		}
	}
	
	public void showDescTotal(){
		//�� ���ⷮ�� ���� �� ���� ���� ����
		total=0;
		System.out.println(Mname+"�� �Ǹ���Ȳ");
		System.out.println("ǰ��\t�ǸŰ���\t���ǸŰ���\t���Ǹűݾ�");
		int row=0,high=0;
		int aa[]=new int[count];
		for(int j=0;j<count;j++) {
			high=0;
			for(int i=0;i<count;i++) {
				if (aa[i] != 0) continue;
				int top=Ilist[i].getTotalprice();
				if(high<= top) {
					row=i;
					high=top;
				}
			}
			aa[row]=j+1;
			total += high;
		}
		
		for(int j=0;j<count;j++) {
			for(int i=0;i<count;i++) {
				if(aa[i]==j+1) {
					String ss="";
					ss += Ilist[i].getIname()+"\t"+Ilist[i].getPrice()+"\t"+Ilist[i].getSellcount()+"\t"+Ilist[i].getTotalprice();
					System.out.println(ss);
				}
				
			}
		}
		System.out.println("�� �Ǹ� �ݾ� : "+total);
	}
	
	
	
	
	
}
