package java_1202;

import java.awt.Point;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame1202 MF=new MyFrame1202("text!");
		// - âũ��
	}

}