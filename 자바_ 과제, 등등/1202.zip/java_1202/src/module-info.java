module java_1202 {
	requires java.desktop;

}