package �������_teampj;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		searchGr.readFile();
		searchGr.print1();
		the_shortest_distance.readFile();
		the_shortest_distance.print2();
	}

}
