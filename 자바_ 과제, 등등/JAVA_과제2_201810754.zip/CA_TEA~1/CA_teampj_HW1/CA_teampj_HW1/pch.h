﻿
#ifndef PCH_H
#define PCH_H

#include <iostream>
#include <iomanip>
#include <cmath>
#define BIT_SIZE  16
#include "operat.h"

using namespace std;


#endif //PCH_H
