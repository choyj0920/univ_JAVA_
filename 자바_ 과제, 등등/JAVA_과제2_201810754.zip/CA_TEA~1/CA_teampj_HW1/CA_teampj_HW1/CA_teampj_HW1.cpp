﻿#include "pch.h"

int main()
{
	operat oper(-7,-3);
	//oper.start_calculate();
	//oper.multiple();
	//oper.division();

	while (true) {
		cout << "두 정수 입력 : ";
		int a, b;
		cin >> a >> b;
		if (!oper.check_range(a, b)) {
			cout << "입력한 숫자가 가능한 범위를 벗어났습니다" << endl;
			continue;
		}
		oper.initial(a, b);
		oper.start_calculate();

		cout << "계속 하시려면 'Y'를 입력하세요";
		char con;
		cin >> con;
		if (!(con == 'y' || con == 'Y')) 
			break;
	}
}

