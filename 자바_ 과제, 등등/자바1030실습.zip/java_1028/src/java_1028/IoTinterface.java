package java_1028;

public interface IoTinterface {
	
	public void turnOn();
	public void turnOff();
}
