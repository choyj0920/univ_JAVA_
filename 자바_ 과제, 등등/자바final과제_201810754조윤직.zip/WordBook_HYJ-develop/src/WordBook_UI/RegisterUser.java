package WordBook_UI;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import WordBook_DATA.UserDatabase;

public class RegisterUser extends JPanel{
	
	public JButton register;
	public JButton back;
	private JTextField id;
	private JPasswordField password;
	private JPasswordField checkPw;
	private FrameManager manager;
	private JOptionPane jOption=new JOptionPane();
	
	
	RegisterUser(FrameManager Fm) {
		setLayout(null);
		this.manager=Fm;
		
		JLabel idLabel=new JLabel("���̵�");
		idLabel.setBounds(31,40,67,15);
		add(idLabel);
		id=new JTextField(20);
		id.setBounds(150,40,80,20);
		add(id);
		id.setColumns(10);
		
		JLabel pwLabel=new JLabel("��й�ȣ");
		pwLabel.setBounds(31,90,90,15);
		add(pwLabel);
		password=new JPasswordField(20);
		password.setBounds(150,90,80,20);
		add(password);
		password.setColumns(10);
		
		JLabel checkPwLabel=new JLabel("��й�ȣ Ȯ��");
		checkPwLabel.setBounds(31,140,140,15);
		add(checkPwLabel);
		checkPw=new JPasswordField(20);
		checkPw.setBounds(150,140,100,20);
		checkPw.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					isSuccessRegister();
				}
			}
		});
		add(checkPw);
		checkPw.setColumns(10);
		
		back=new JButton("�ڷ� ����");
		back.setBounds(300,130,120,70);
		add(back);
		back.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				manager.changeFrame("����â");				
			}
		});
		
	    register = new JButton("ȸ������ Ȯ��");
        register.setBounds(300,200,120,70);
        this.add(register);        
        register.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				isSuccessRegister();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	void isSuccessRegister() {
		String Id=id.getText();
		String pw=password.getText();
		String checkpw=checkPw.getText();
		
		if(Id.equals("")||pw.equals("")|| checkpw.equals("")) {
			jOption.showMessageDialog(null,"�ٽ� Ȯ�����ּ���");
		}else if(!pw.equals(checkpw)){
			jOption.showMessageDialog(null,"��й�ȣ�� ���������ʽ��ϴ�.");
		}else{
			if(UserDatabase.registerUser(Id, pw)) {
				jOption.showMessageDialog(null,"����ȸ�� ���� �Ǿ����ϴ�");
				((FrameManager) manager).changeFrame("����â");
			}
			else {
				jOption.showMessageDialog(null,"�����ϴ� ���̵� �Դϴ�.");
				
			}
			
		}
	}
	
}
