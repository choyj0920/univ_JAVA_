package WordBook_UI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import WordBook_DATA.UserDatabase;
import WordBook_DATA.Word;
import WordBook_DATA.Worddata;


public class myWordBook extends JPanel {

	private FrameManager manager;
	
	JPanel wordlistpanel;
	JPanel controllpanel;
	JList<String>list;
	JButton btn;
	JButton addbtn;

	public myWordBook(FrameManager Fm) {
		manager = Fm;
		
		init();
		
		
	}
	void init() {
		this.removeAll();
		
		btn=new JButton("�� �ܾ��忡�� ����");
		btn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					String[] ss=list.getSelectedValue().split(":");
					String worde=ss[1].split(",")[0].trim();
					manager.nowUser.userWordbook.remove(worde);
					JOptionPane.showMessageDialog(null,"���������� ���ŵǾ����ϴ�.");
					UserDatabase.saveuserdata();
					init();
					
				} catch (Exception e2) {
					// TODO: handle exception
					System.out.println(e.toString());
					JOptionPane.showMessageDialog(null,"���� �߻�..�ܾ ����� ���õ��� �ʾҽ��ϴ�.");
				}
				
				
			}
		});
		
		setLayout(new BorderLayout());
		controllpanel=new JPanel();
		controllpanel.setLayout(new FlowLayout(1000,1, FlowLayout.LEFT));
		controllpanel.add(btn);
		addbtn=new JButton("���ο� �ܾ��߰�!");
		addbtn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new MyDialog(manager,"��ȭ����",true);
				UserDatabase.saveuserdata();
				init();
			}
		});
		controllpanel.add(addbtn);
		ArrayList<Word> arr=new ArrayList<Word>();
		arr.addAll(manager.nowUser.userWordbook.values());
		String[] ss= new String[arr.size()];
		for(int i=0; i<ss.length;i++) {
			ss[i]=arr.get(i).toString();
		}
		list=new JList(ss);
		if(manager.nowUser!=null)
			add(controllpanel,BorderLayout.EAST);
		wordlistpanel=new JPanel();
		wordlistpanel.setLayout(new BorderLayout());
		wordlistpanel.add(new JScrollPane(list));
		add(wordlistpanel);
		manager.getContentPane().validate();
	}
}

class MyDialog extends JDialog{
	FrameManager parent;
	JPanel panel;
	JTextField worde,wordmean;
	JPasswordField mpasswd1;
	JPasswordField mpasswd2;
	JTextField maddr;
	JTextField mtel;
	JButton btn;
	
	public MyDialog(FrameManager frame,String title,boolean modal ) {
		super(frame,title,modal);//��� - ��Ŀ�� ���� ����
		parent=frame;
		this.setLayout(new BorderLayout());
		init();
		this.setSize(200,400);
		
		// �� â�� ���� ��Ű�� ���ִ� ����̳� �׷��� ���� - ��â�� ����ǰ�
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}
	void init(){
		panel=new JPanel(new GridLayout(4,1));
		worde=new JTextField(30);
		wordmean=new JTextField(30);
		
		btn=new JButton("�ܾ� �߰�");
		btn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String word_e=worde.getText();
				String[] means=wordmean.getText().split("/");
				if(parent.nowUser.userWordbook.containsKey(word_e)) {
					JOptionPane.showMessageDialog(null,"�̹� ���� �ϴ� �ܾ��Դϴ�.");
				}
				else {
					parent.nowUser.userWordbook.put(word_e,new Word(word_e, means));
					JOptionPane.showMessageDialog(null,"���������� �߰��Ǿ����ϴ�.");
					dispose();
				}
			}
		});
		
		panel.add(new JLabel("�ܾ�(����) : "));
		panel.add(worde);
		panel.add(new JLabel("�ܾ��ǹ� (��������/�� ����) :"));
		panel.add(wordmean);
		
		this.add(panel);
		this.add(btn,BorderLayout.NORTH);
		
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				super.windowClosing(e);
				dispose();
			}
		});
	}
	
	
}

