package WordBook_UI;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import WordBook_DATA.UserDatabase;
import WordBook_DATA.Worddata;

public class MultipleChoice extends JPanel {


   private FrameManager manager;
   JLabel english;
   JCheckBox[] nums = new JCheckBox[5];
   JButton check;
   int index, answerNum, problemNum;

   Random random = new Random();

   public MultipleChoice(FrameManager Fm) {
      this.manager = Fm;
      setLayout(new FlowLayout());

      index = random.nextInt(100);
      english = new JLabel(Worddata.wordbook.get(index).getWord_e().trim());
      english.setBounds(50, 10, 150, 150);
      this.add(english);

      answerNum = random.nextInt(4);

      for (int i = 0; i < 4; i++) {
         problemNum = random.nextInt(Worddata.wordbook.get(index).getWord_e().length());
         if (answerNum == i) {
            nums[i] = new JCheckBox(Worddata.wordbook.get(index).randMean());
         } else {
            nums[i] = new JCheckBox(Worddata.wordbook.get(problemNum).randMean());
         }
         this.add(nums[i]);
      }

      check = new JButton("����Ȯ��");
      check.setBounds(380, 500, 200, 50);
      this.add(check);
      check.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            JOptionPane jOption = new JOptionPane();
            for (JCheckBox num : nums) {
               if (num.isSelected()) {
                  if (Worddata.wordbook.get(index).correct(num.getText().trim())) {
                     jOption.showMessageDialog(null, "����.");
                     num.setSelected(false);
                     newProblem();
                     break;
                  } else {
                	  if(manager.nowUser != null) {
                		  if(manager.nowUser.putword(Worddata.wordbook.get(index).getWord_e(),
                				  Worddata.wordbook.get(index).getMean())) {
                			  jOption.showMessageDialog(null, "����., �ܾ��忡 �߰�..");   
                		  }
                		  else
                			  jOption.showMessageDialog(null, "����.,�ܾ��忡 �̹� ����..");   
                			  
                		  UserDatabase.saveuserdata();                		 
                	  }
                	  else
                		  jOption.showMessageDialog(null, "����.");                		  
                     num.setSelected(false);
                     newProblem();
                     break;
                  }
               }
            }

         }
      });

   }

   public void newProblem() {
      index = random.nextInt(Worddata.wordbook.get(index).getWord_e().length());
      english.setText((Worddata.wordbook.get(index).getWord_e().trim()));
      english.setBounds(50, 10, 150, 150);
      this.add(english);
      randomNumber();
   }

   public void randomNumber() {
      answerNum = random.nextInt(4);

      for (int i = 0; i < 4; i++) {
         problemNum = random.nextInt(Worddata.wordbook.get(index).getWord_e().length());
         if (answerNum == i) {
            nums[i].setText((Worddata.wordbook.get(index).randMean()));
         } else {
            nums[i].setText((Worddata.wordbook.get(problemNum).randMean()));
         }
         this.add(nums[i]);
      }

   }

}