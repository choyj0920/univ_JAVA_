package WordBook_UI;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;



import WordBook_DATA.UserDatabase;
import WordBook_DATA.Word;
import WordBook_DATA.Worddata;

public class ShortAnswerQuestion extends JPanel {
   private FrameManager manager;
   
   JButton check;
   Random random = new Random();
   JTextField userAnswer;
   JLabel english;
   int index;

   public ShortAnswerQuestion(FrameManager Fm) {
      this.manager = Fm;
      setLayout(null);

      index = random.nextInt(100);
      
      JLabel label =new JLabel("�ְ��� ����");
      label.setFont(new Font("Serif",Font.BOLD,40));
      label.setBounds(220, 2, 300, 50);
      this.add(label);
      
      english = new JLabel(Worddata.wordbook.get(index).getWord_e().trim());
      english.setFont(new Font("Serif",Font.BOLD,35));
      english.setBounds(40, 30, 300, 150);
      this.add(english);

      userAnswer = new JTextField();
      userAnswer.setBounds(250, 92, 300, 38);
      this.add(userAnswer);

      check = new JButton("����Ȯ��");
      check.setBounds(250, 170, 120, 40);
      this.add(check);
      check.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            JOptionPane jOption = new JOptionPane();
            System.out.println(Worddata.wordbook.get(index)+"\n"+userAnswer.getText());
            if (Worddata.wordbook.get(index).correct(userAnswer.getText().trim())) {
               jOption.showMessageDialog(null, "����.");
               probelm();
               return;
            } else {
            	 if(manager.nowUser != null) {
           		  manager.nowUser.putword(Worddata.wordbook.get(index).getWord_e(),
           				  Worddata.wordbook.get(index).getMean());
           		  jOption.showMessageDialog(null, "����., �ܾ��忡 �߰�..");   
           		  UserDatabase.saveuserdata();                		 
           	  }
           	  else
           		  jOption.showMessageDialog(null, "����.");   

              
               probelm();
               return;
            }

         }
      });

   }
   public void probelm() {
      userAnswer.setText(null);
      index = random.nextInt(100);
      english.setText(Worddata.wordbook.get(index).getWord_e());
   }
}