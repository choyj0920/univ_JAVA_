package WordBook_UI;

import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class SelectLogin extends JPanel{
	
	private FrameManager frame;
	private JButton register;
	private JButton nonMemberView;
	private JButton loginVeiw;
	private JLabel title;
	
	public SelectLogin(FrameManager frameManager) {
		
		
		setSize(330,100);
		setLayout(null);
		frame=frameManager;
		
		title =new JLabel("�ܾ���~");
		title.setFont(new Font("Serif",Font.BOLD,40));
		title.setBounds(250,0,400,100);
		this.add(title);
		
		 register = new JButton("ȸ������");
	        register.setBounds(50,90, 120, 70);
	        this.add(register);        
	        register.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					((FrameManager) frame).changeFrame("ȸ������");
				}
			});
	        
	        loginVeiw = new JButton("�α���");
	        loginVeiw.setBounds(230,90,120,70);
	        this.add(loginVeiw);        
	        loginVeiw.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					((FrameManager) frame).changeFrame("�α���");
				}
			});
	        
	        nonMemberView = new JButton("��ȸ��");
	        nonMemberView.setBounds(410,90,120,70);
	        this.add(nonMemberView);        
	        nonMemberView.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					frameManager.nowUser=null;
					((FrameManager) frame).changeFrame("�ܾ���View");
				}
			});
	        setVisible(true);
		
	}
	
	
	
	
	
	
}
