package WordBook_UI;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class WordBookMainPanel extends JPanel implements ActionListener {

	private FrameManager manager;
	private JButton wordBook;
	private JButton wordQuiz;
	private JButton myWordBook;
	private JButton back;
	JPanel menupanel= new JPanel();
	JPanel selectpanel;

	public WordBookMainPanel(FrameManager Fm) {
		// TODO Auto-generated constructor stub
		setLayout(new BorderLayout());
		manager = Fm;
		
		selectpanel=new JPanel(new BorderLayout());
		
		menupanel.setLayout(new GridLayout(1,4));
		
		wordBook = new JButton("�ܾ��� ����");		
		wordBook.addActionListener(this);		
		menupanel.add(wordBook);
		
		wordQuiz = new JButton("����");		
		wordQuiz.addActionListener(this);
		menupanel.add(wordQuiz);
		if(manager.nowUser !=null) {
			myWordBook = new JButton("������ �ܾ���");		
			myWordBook.addActionListener(this);
			menupanel.add(myWordBook);			
		}
		
		back=new JButton("ó������ ���ư���");
		back.addActionListener(this);
		menupanel.add(back);
		
		this.add(menupanel,BorderLayout.NORTH);
		this.add(selectpanel);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==wordBook) {
			selectpanel.removeAll();
			selectpanel=new TotalWordBook(manager);
			this.add(selectpanel);
			manager.getContentPane().revalidate();
		}
		if(e.getSource()==wordQuiz) {
			selectpanel.removeAll();
			selectpanel=new QuizPanel(manager);
			this.add(selectpanel);
			manager.getContentPane().revalidate();
		}
		if(e.getSource()==myWordBook) {
			selectpanel.removeAll();
			selectpanel=new myWordBook(manager);
			this.add(selectpanel);
			manager.getContentPane().revalidate();
			
		}
		if(e.getSource()==back) {
			selectpanel.removeAll();
			manager.changeFrame("����â");
		}
	}
}
