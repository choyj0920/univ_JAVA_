package WordBook_UI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class QuizPanel extends JPanel {

	private FrameManager manager;
	private JButton shortAnswerQuestion;
	private JButton multipleChoice;

	public QuizPanel(FrameManager manager) {
		this.manager = manager;
		setLayout(null);
		
		shortAnswerQuestion = new JButton("�ְ���");
		shortAnswerQuestion.setBounds(200, 60, 120, 70);
		this.add(shortAnswerQuestion);
		shortAnswerQuestion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				setLayout(new BorderLayout());
				add(new ShortAnswerQuestion(manager));
				manager.validate();
			}
		});
		
		multipleChoice = new JButton("������");
		multipleChoice.setBounds(380, 60, 120, 70);
		this.add(multipleChoice);
		multipleChoice.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				removeAll();
				setLayout(new BorderLayout());
				add(new MultipleChoice(manager));
				manager.validate();
			}
		});
	}
	
}
