package WordBook_DATA;

import java.util.HashMap;

public class User{
	public String userId,userPw;
	//public int testword;
	public HashMap<String, Word> userWordbook=new HashMap<String, Word>();
	
	User(String userId, String userPw){
		this.userId=userId; this.userPw=userPw; 
		userWordbook=new HashMap<String, Word>();
	}
	User(String userId, String userPw, HashMap<String, Word> userWordbook){
		this.userId=userId; this.userPw=userPw; 
		this.userWordbook=userWordbook;
	}
	
	public boolean putword(String worde,String[] means) {
		if(userWordbook.containsKey(worde)) {
			return false;
		}
		userWordbook.put(worde, new Word(worde,means));
		UserDatabase.saveuserdata();
		return true;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return userId+"\n"+userPw+"\n"+userWordbook.size()+"\n";
	}
	public String tofile() {
		String ss="";
		for(Word w: userWordbook.values()) {
			ss+=w.toFile();
		}
		
		return userId+"\n"+userPw+"\n"+userWordbook.size()+"\n"+ss;
	}
}