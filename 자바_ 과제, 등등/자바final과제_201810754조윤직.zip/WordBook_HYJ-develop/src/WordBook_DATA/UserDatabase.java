package WordBook_DATA;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class UserDatabase {
	
	static HashMap<String, User> userdatabase=new HashMap<String, User>();
		
	
	public static User loaduserfile(String id, String pw){
		if(userdatabase.containsKey(id)&& 
				userdatabase.get(id).userPw.equals(pw)) {
			return userdatabase.get(id);
		}
		
		return null;
		
	}
	
	public static boolean registerUser(String id,String pw) {
		if(userdatabase.containsKey(id))
			return false;
		else {
			userdatabase.put(id, new User(id, pw));
			saveuserdata();
			return true;
		}
	}
	
	public static void loadUserdb() {
		File file =new File("userdatabase.txt");
		Scanner scan;
		try {
			scan = new Scanner(file);
			while(scan.hasNext()) {
				String userID=scan.nextLine().trim();
				String userPw=scan.nextLine().trim();
				int userWordCount=scan.nextInt();
				scan.nextLine();
				HashMap<String, Word> userwordbook=new HashMap<String, Word>();
				for(int i=0; i<userWordCount;i++) {
					String word_e= scan.nextLine().trim();
					String[] mean=scan.nextLine().split("/");
					for(int j=0; j<mean.length;j++) {
						mean[j]=mean[j].trim();
					}
					userwordbook.put(word_e, new Word(word_e,mean));
					
				}
				userdatabase.put(userID,new User(userID, userPw, userwordbook));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("db���� ����");
			e.printStackTrace();
		}		
	}
	
	public static void saveuserdata() {
		File file=new File("userdatabase.txt");
		//���� ��ü ����  
	    try {
	      FileWriter fw = new FileWriter(file);	      
	      for(User u: userdatabase.values()) {
	    	  fw.write(u.tofile());
	      }
	      fw.close();
	      
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	}
}
