package WordBook_DATA;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import WordBook_UI.SelectLogin;

public class Worddata {
	public static LinkedList<Word>wordbook=new LinkedList<Word>();
	public static void set_wordbook() {
		File file = new File("words.txt");
		Scanner scans;
		try {
			scans = new Scanner(file);
			while (scans.hasNextLine()) {
				String eng = scans.nextLine().trim();
				String[] mean = (scans.nextLine().trim()).split("/");
				for (int i = 0; i < mean.length; i++) {
					mean[i] = mean[i].trim();
				}
				wordbook.add(new Word(eng, mean));
			}
			scans.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println();
		}	 
		

	}


	
}
